import * as React from 'react';
import Box from '@mui/material/Box';
import Input from '@mui/material/Input';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import { useQuery, gql, useMutation } from '@apollo/client';
import '../css/student.css'
import { Button } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import Alert from '@mui/material/Alert';
import Snackbar from '@mui/material/Snackbar';
import TextField from "@mui/material/TextField";
import LinearProgress from '@mui/material/LinearProgress';
import Autocomplete from '@mui/material/Autocomplete';
import Container from "@mui/material/Container";
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import '../css/global.css'
import RepresentativeTable from '../components/RepresentativeTable'

const ADD_REPRESENTATIVE_MUTATION = gql`
mutation AddRepresentative($representative: RepresentativeInput){
    addRepresentative(representative:$representative){
      name
    }
  }
`;

const GET_STUDENTS = gql`
query AllStudents{
    allStudents(search:{}){
      id
      fullName
    }
  }
`;

export default function Representative() {

    const navigate = useNavigate();
    const [representativeName, setRepresentativeName] = React.useState('');
    const [openSnackbar, setOpenSnackbar] = React.useState(false);
    const [selectedStudent, setSelectedStudent] = React.useState('');
    const [tabValue, setTabValue] = React.useState('all');
    const [snackbarMessage, setSnackbarMessage] = React.useState('');

    const { loading: studentsMLoading, error: studentsMError, data: studentsData } = useQuery(GET_STUDENTS);
    const [submitRepresentative, { loading: mLoading, error: mError }] = useMutation(ADD_REPRESENTATIVE_MUTATION);


    const handleChangeTab = (event, newValue) => {
        setTabValue(newValue)
    }

    const handleRepresentativeName = (event) => {
        setRepresentativeName(event.target.value);
    }

    const handleSelectedStudent = (event, value) => {
        setSelectedStudent(value);
    };

    const handleSubmit = () => {
        submitRepresentative({
            variables: {
                representative: { name: representativeName, studentName: selectedStudent.fullName }
            }
        }).then(() => {
            setOpenSnackbar(true);
            setSnackbarMessage('Apoderado registrado satisfactoriamente');
            setTimeout(() => {
                
                setRepresentativeName('')
                setSelectedStudent('')
                setTabValue('all')
            }, 2000);
        }).catch((error) => {
            setOpenSnackbar(true);
            setSnackbarMessage('Error al registrar el apoderado');
        });
    }

    const handleClose = () => {
        setOpenSnackbar(false);
    }


    if (studentsMLoading) {
        return (
            <Box sx={{ width: '100%' }}>
                <LinearProgress />
            </Box>)
    }
    if (mLoading) {
        return (
            <Box sx={{ width: '100%' }}>
                <LinearProgress />
            </Box>)
    }
    return (
        <Container component="main" >
            <Box sx={{ width: '100%', bgcolor: 'background.paper', mt: 10, mb: 5 }}>
                <Tabs value={tabValue} onChange={handleChangeTab} centered>
                    <Tab value="all" label="Todos" />
                    <Tab value="create" label="Registrar Apoderado" />
                </Tabs>
            </Box>
            {tabValue === 'all' && (
                <RepresentativeTable tabValue={tabValue} />
            )}

             {(tabValue == "create") && (
                <Box  sx={{ width: '300px', margin: 'auto' }}>
                <TextField required fullWidth sx={{ mb: 2, mt: 5 }} id="name" name="name" placeholder="Nombre" value={representativeName} onChange={handleRepresentativeName} />

                {studentsData ? (
                    <Autocomplete
                        id="demo-simple-select"
                        sx={{ mb: 2 }}
                        options={studentsData.allStudents || []}
                        getOptionLabel={(option) => option.fullName ? option.fullName : ''}
                        value={selectedStudent}
                        onChange={handleSelectedStudent}
                        renderInput={(params) => (
                            <TextField {...params} label="Estudiante"/>
                        )}
                        renderOption={(props, option) => (
                            <li {...props} key={option.id}>
                                <TextField sx={{ "& fieldset": { border: "none" } }}
                                    value={option.fullName ? option.fullName : ''}
                                />
                            </li>
                        )}
                    />
                ) : (
                    <div>Loading students...</div>
                )}


                <Button fullWidth sx={{ mb: 2 }} type="submit" variant="contained" onClick={handleSubmit}>Submit</Button>

            </Box>
             )}
            
            {openSnackbar && (<Snackbar
                open={openSnackbar}
                autoHideDuration={3000}
                onClose={() => setOpenSnackbar(false)}
                anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
            >
                <Alert onClose={() => setOpenSnackbar(false)} severity="info" sx={{ width: '100%' }}>
                    {snackbarMessage}
                </Alert>
            </Snackbar>)}
        </Container>
    )
};
