import * as React from 'react';
import Box from '@mui/material/Box';
import { gql, useMutation } from '@apollo/client';
import { Button } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import LinearProgress from '@mui/material/LinearProgress';
import TextField from "@mui/material/TextField";
import Container from "@mui/material/Container";
import Snackbar from '@mui/material/Snackbar';
import Alert from '@mui/material/Alert';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import WorkshopTable from '../components/WorkshopTable';


const ADD_WORKSHOP = gql`
mutation AddWorkshop($workshop:WorkshopInput){
    addWorkshop(workshop:$workshop){
      name
    }
  }
`;

const Workshop = () => {

    const navigate = useNavigate();
    const [tabValue, setTabValue] = React.useState('all');
    const [openSnackbar, setOpenSnackbar] = React.useState(false);
    const [snackbarMessage, setSnackbarMessage] = React.useState('');
    const [schedule, setSchedule] = React.useState([]);

    const [name, setName] = React.useState('');
    const [price, setPrice] = React.useState(0);

    const [submitWorkshop, { loading: workshopLoading}] = useMutation(ADD_WORKSHOP);
    

    const handleChangeTab = (event, newValue) => {
        setTabValue(newValue)
    }

    const handleChangeName = (event) => {
        setName(event.target.value)
    }

    const handleChangeSchedule = (event) => {
        setSchedule(event.target.value.split(','))
    }

    const handleChangePrice = (event) => {
        setPrice(event.target.value)
    }

    const handleSubmit = () => {
        submitWorkshop({
            variables: {
                workshop: { name, schedule, price }
            }
        }).then(() => {
            setOpenSnackbar(true);
            setSnackbarMessage('Taller registrado satisfactoriamente');
            setTimeout(() => {
                setName('')
                setSchedule([])
                setPrice('')
                setTabValue('all')
                navigate('/workshop');
            }, 1000);
        }).catch((error) => {
            setOpenSnackbar(true);
            setSnackbarMessage('Error al registrar el taller');
        });
    }


    if (workshopLoading) {
        return (
            <Box sx={{ width: '100%' }}>
                <LinearProgress />
            </Box>)
    }
    if (workshopLoading) {
        return (
            <Box sx={{ width: '100%' }}>
                <LinearProgress />
            </Box>)
    }

    return (
        <Container component="main">
            <Box sx={{ width: '100%', bgcolor: 'background.paper', mt: 10, mb: 5 }}>
                <Tabs value={tabValue} onChange={handleChangeTab} centered>
                    <Tab value="all" label="Todos" />
                    <Tab value="create" label="Registrar Taller" />
                </Tabs>
            </Box>

            {tabValue === 'all' && (
                <WorkshopTable tabValue={tabValue} />
            )}


            {(tabValue === "create") && (
                <Box sx={{ width: '300px', margin: 'auto'}}>
                    <TextField fullWidth sx={{ mb: 2 }} placeholder="Nombre" value={name} onChange={handleChangeName} />
                    <TextField fullWidth sx={{ mb: 2 }} placeholder="Horarios" value={schedule.join(',')} onChange={handleChangeSchedule} />
                    <TextField fullWidth sx={{ mb: 2 }} placeholder="Precio" value={price} onChange={handleChangePrice} />
                    <Button fullWidth sx={{ mb: 2 }} type="submit" variant="contained" onClick={handleSubmit}>Registrar</Button>
                </Box>
            )}

            {openSnackbar && (<Snackbar
                open={openSnackbar}
                autoHideDuration={3000}
                onClose={() => setOpenSnackbar(false)}
                anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
            >
                <Alert onClose={() => setOpenSnackbar(false)} severity="info" sx={{ width: '100%' }}>
                    {snackbarMessage}
                </Alert>
            </Snackbar>)}
        </Container>
    )
};

export default Workshop;